package pt.uma.arq.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import pt.uma.arq.entities.Items;
import pt.uma.arq.entities.Player;
import pt.uma.arq.game.BitmapFont;

public class Game extends ApplicationAdapter {
    private SpriteBatch batch;
    private BackgroundManagement backgroundManagement;
    private BitmapFont font;
    private Player player;
    private Items items;
    private Sound sound;

    @Override
    public void create() {
        // Classe principal que define a lógica do jogo.
        Gdx.graphics.setWindowedMode(1280, 800);
        batch = new SpriteBatch();
        player = new Player(100, 100, batch, "frog_idle.png", 1, 11);
        player.create();
        items = new Items(batch);
        items.createItems();
        font = new BitmapFont(Gdx.files.internal("gamefont.fnt"), Gdx.files.internal("gamefont.png"), false);
        backgroundManagement = new BackgroundManagement(batch);
        sound = Gdx.audio.newSound(Gdx.files.internal("sound.mp3"));
        sound.play(1.0f);
    }

    @Override
    public void render() {
        // Método para renderizar o jogo e atualizar a lógica.
        Gdx.gl.glClearColor(0, 0, 0.2f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        batch.begin();
        backgroundManagement.render();
        font.drawText(50, 750, "Pontuacao=" + player.getScore(), batch);
        font.drawText(1150, 750, "Vida=" + player.getLife(), batch);


        items.collidedWithPlayer(player);
        player.update();
        items.updateItems();
        player.render();
        items.renderItems();
        if (player.getScore() == 1500){
            items.stopItems();
            player.stopBullets();
            font.drawText(550, 400, "GANHASTE!!!", batch);
            sound.dispose();
        }
         if (player.getLife()== 0){
             items.stopItems();
             player.stopBullets();
             font.drawText(550, 400, "GAME OVER", batch);
             sound.dispose();
         }

        batch.end();
    }

    @Override
    public void dispose() {
        batch.dispose();
    }
}
