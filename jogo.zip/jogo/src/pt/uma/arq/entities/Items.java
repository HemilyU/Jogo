package pt.uma.arq.entities;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Timer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Random;

import static pt.uma.arq.entities.ItemType.TRAP;

public class Items {
    SpriteBatch batch;
    private ArrayList<Item> items;



    String[] arrayFruit = {"apple.png", "melon.png", "pineapple.png"};
    String[] arrayTrap = {"razor_disc.png", "spiked_stone.png", "square_stone.png"};

    int[] arrayColTrap = {8, 4, 4};

    public Items(SpriteBatch batch) {
        // Classe para gerenciar os itens no jogo (frutas e objetos perigosos).
        this.batch = batch;
        items = new ArrayList<Item>();
    }

    public void createItems() {


        // Cria itens aleatórios no jogo.
        Random rand = new Random();
        for (int i = 1; i <= 30; i++) {
            int rand_img = rand.nextInt(3);
            int rand_x = rand.nextInt(1280);
            Vector2 vel = new Vector2();
            vel.x = rand.nextInt(5);
            vel.y = rand.nextInt(5);
            Item item = new Item(rand_x, 1000, batch, arrayFruit[rand_img], 1, 17, ItemType.FRUIT, vel, rand.nextBoolean());
            item.create();
            this.items.add(item);
        }
        for (int i = 1; i <= 30; i++) {
            int rand_img = rand.nextInt(3);
            int rand_x = rand.nextInt(1280);
            Vector2 vel = new Vector2();
            vel.x = rand.nextInt(5);
            vel.y = rand.nextInt(5);

            Item item = new Item(rand_x, 1000, batch, arrayTrap[rand_img], 1, arrayColTrap[rand_img], TRAP, vel, rand.nextBoolean());
            item.create();
            this.items.add(item);
        }

        Collections.shuffle(items);

        final Items self= this;//Variavel do tipo Items para poder aceder as funções da mesma
        Timer timer = new Timer();//Variavel de tempo para controlar a quantidade de frutas visiveis

        timer.scheduleTask( new Timer.Task(){
            @Override
            public void run() {
                self.setFruitVisible();//Chama a função setFruitsVisible() para tornar uma das frutas Visiveis
            }
        },1,1,-4);
    }

    public void setFruitVisible(){
        for (Item item : items) {
            if(!item.isVisible()){
                item.setVisible(true);
                break;
            }
        }
    }

    public void updateItems() {
        // Atualiza a posição dos itens no jogo.
        for (Item item : items) {
            if(item.isVisible()){
                item.update();
            }
        }

        Iterator<Item> iterator = items.iterator();
        while (iterator.hasNext()) {
            Item item = iterator.next();
            if (item.isCollided() || item.isOutOfBounds()) {
                //createExplosion(item.x, item.y);
                iterator.remove();
            }
        }
    }


    /*public void createExplosion(int x, int y){
        Explosion exp= new Explosion(x, y, this.batch, "explosion.png", 5, 1);
        exp.create();
    }*/

    public void renderItems() {
        // Renderiza os itens no jogo.
        for (Item item : items) {
            item.render();
        }
    }

    public void collidedWithPlayer(Player player) {
        // Verifica colisões entre os items, o jogador e as balas.
        for (Item item : items) {
            item.collidedWith(player);
            if (item.isCollided()) {
                if (item.type == ItemType.FRUIT) {
                    player.setScore(100);
                } else if (item.type == TRAP) {
                    player.removeLife(1);
                }
            }

            if (item.type == TRAP){
                for (Bullet bullet : player.getBullets()) {
                    if (!bullet.isCollided()) {
                        bullet.collidedWith(item);
                        if (bullet.isCollided()){
                            player.setScore(100);
                            item.collided= true;
                        }
                    }
                }
            }

        }
    }

    public void stopItems(){
        this.items= new ArrayList<Item>();
    }
}
