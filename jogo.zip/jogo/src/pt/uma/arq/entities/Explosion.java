package pt.uma.arq.entities;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Explosion extends AnimatedSprite{

    boolean visible;
    public Explosion(int x, int y, SpriteBatch batch, String path, int rows, int columns) {
        super(x, y, batch, path, rows, columns);// Construtor da classe pai
    }



    @Override
    public void update() {

    }

    @Override
    public void render() {
        super.render();
    }
}
