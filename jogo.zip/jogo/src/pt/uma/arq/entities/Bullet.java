package pt.uma.arq.entities;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Bullet extends AnimatedSprite{
    public Bullet(int x, int y, SpriteBatch batch, String path, int rows, int columns) {
        super(x, y, batch, path, rows, columns);// Construtor da classe pai
    }

    @Override
    public void update() {
        this.y += 3;// Move a bala para cima

        if(this.y >= 800){
            this.outOfBounds= true;
        }

        boundingBox.setPosition(this.x,this.y);
    }

    @Override
    public void render() {
        super.render();
    }
}
