package pt.uma.arq.entities;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import pt.uma.arq.game.Animator;

public abstract class AnimatedSprite {
    protected Animator animator; // Um objeto responsável pela animação
    protected int x; // Posição x
    protected int y; // Posição y
    protected Rectangle boundingBox; // Área delimitadora para detecção de colisão
    protected Boolean collided; // Indica se colidiu
    protected Boolean outOfBounds; // Indica se está fora dos limites

    // Construtor
    public AnimatedSprite(int x, int y, SpriteBatch batch, String path, int rows, int columns) {
        this.x = x;
        this.y = y;
        this.collided = false;
        this.outOfBounds = false;
        this.animator = new Animator(batch, path, columns, rows); // Inicializa o objeto de animação
    }

    public boolean isCollided() {
        return this.collided; // Retorna o estado de colisão
    }

    public boolean isOutOfBounds() {
        return this.outOfBounds; // Retorna o estado de estar fora dos limites
    }

    public void create() {
        this.animator.create(); // Inicializa a animação
        this.boundingBox = new Rectangle(x, y, animator.getWidth(), animator.getHeight()); // Inicializa a área delimitadora
    }

    public abstract void update(); // Método abstrato para atualização
    public void render() {
        animator.render(x, y); // Renderiza o sprite
    }

    public void collidedWith(AnimatedSprite other) {
        this.collided = this.boundingBox.overlaps(other.boundingBox); // Verifica a colisão
    };
}
