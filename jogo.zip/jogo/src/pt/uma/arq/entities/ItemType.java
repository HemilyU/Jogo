package pt.uma.arq.entities;

public enum ItemType {
    FRUIT, // Enumeração para tipos de itens (frutas)
    TRAP   // Enumeração para tipos de itens (armadilhas)
}
