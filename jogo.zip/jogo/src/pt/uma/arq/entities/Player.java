package pt.uma.arq.entities;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import java.util.ArrayList;
import java.util.Iterator;

public class Player extends AnimatedSprite {
    SpriteBatch batch;
    private ArrayList<Bullet> bullets; // Lista de balas

    private int score; // Pontuação do jogador

    private int life;

    private Sound laserSound;

    public Player(int x, int y, SpriteBatch batch, String path, int rows, int columns) {
        super(x, y, batch, path, rows, columns);
        this.batch = batch;
        this.score = 0;
        this.life= 3;
        bullets = new ArrayList<Bullet>();
        this.laserSound= Gdx.audio.newSound(Gdx.files.internal("laser.mp3"));
    }

    public void handleInput() {
        if (Gdx.input.isKeyPressed(Input.Keys.RIGHT) && this.x < 1225) {
            this.x += 5; // Move para a direita
        } else if (Gdx.input.isKeyPressed(Input.Keys.LEFT) && this.x > 0) {
            this.x -= 5; // Move para a esquerda
        }
        if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) {
            Bullet bullet = new Bullet(this.x, this.y, this.batch, "laser-bolts.png", 2, 2); // Cria uma bala
            bullet.create();
            bullets.add(bullet); // Adiciona a bala à lista
        }
    }

    public ArrayList<Bullet> getBullets() {
        return bullets; // Retorna a lista de balas
    }

    public void setBullets(ArrayList<Bullet> bullets) {
        this.bullets = bullets; // Define a lista de balas
    }

    public int getScore() {
        return score; // Retorna a pontuação do jogador
    }

    public void setScore(int score) {
        this.score += score; // Atualiza a pontuação
    }

    public int getLife() {
        return life;
    }

    public void removeLife(int life) {
        this.life -= life;
    }

    @Override
    public void update() {
        handleInput(); // Lida com a entrada do jogador
        boundingBox.setPosition(x, y);

        for (Bullet bullet : bullets) {
            bullet.update(); // Atualiza as balas
            //laserSound.play(0.3f);
        }

        Iterator<Bullet> iterator = bullets.iterator();
        while (iterator.hasNext()) {
            Bullet bullet = iterator.next();
            if (bullet.isCollided()) {
                iterator.remove();
            }
            if (bullet.isOutOfBounds()) {
                iterator.remove();
            }
        }
    }

    @Override
    public void render() {
        super.render(); // Renderiza o jogador
        for (Bullet bullet : bullets) {
            bullet.render(); // Renderiza as balas
        }
    }

    public void stopBullets(){
        this.bullets= new ArrayList<Bullet>();
    }
}
