package pt.uma.arq.entities;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;

public class Item extends AnimatedSprite {
    protected ItemType type; // Tipo de item (fruta ou armadilha)
    private Vector2 velocity; // Velocidade do item
    private boolean side; // Lado para o qual o item se move

    private boolean visible;

    public boolean isVisible(){
        return this.visible;
    }

    public void setVisible(boolean visible){
        this.visible= visible;
    }

    public Item(int x, int y, SpriteBatch batch, String path, int rows, int columns, ItemType type, Vector2 v, boolean side) {
        super(x, y, batch, path, rows, columns); // Construtor da classe pai
        this.type = type;
        this.velocity = v;
        this.side = side;
        this.visible=false;

    }

    @Override
    public void update() {
        if (y < 0) {
            this.outOfBounds = true; // Define como fora dos limites quando a posição y é menor que 0
        }

        if (this.x >= 1280 || this.x <= 0) {
            velocity.x *= -1; // Inverte a direção quando atinge as bordas
        }
        if (side) {
            this.x += (int) velocity.x; // Move para a direita
        } else {
            this.x -= (int) velocity.x; // Move para a esquerda
        }
        this.y -= (int) velocity.y; // Move para cima
        boundingBox.setPosition(x, y); // Atualiza a posição da área delimitadora
    }
}
